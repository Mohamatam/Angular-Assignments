import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AdminComponent } from './admin/admin.component';
import { MenuComponent } from './menu/menu.component';
import { RestaurantComponent } from './restaurant/restaurant.component';
import { UserComponent } from './user/user.component';
import {ButtonModule} from 'primeng/button';
import { AdminModuleRoutingModule } from './admin/admin-module/admin-module-routing.module';
@NgModule({
  declarations: [
    AppComponent,
    AdminComponent,
    //  myRoutings 

    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ButtonModule,
    AdminModuleRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
