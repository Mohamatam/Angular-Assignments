import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MenuComponent } from 'src/app/menu/menu.component';
import { RestaurantComponent } from 'src/app/restaurant/restaurant.component';
import { UserComponent } from 'src/app/user/user.component';

const routes: Routes = [
  {path: 'menu',component: MenuComponent},
  {path: 'restaurant',component: RestaurantComponent},
  {path: 'user', component: UserComponent}
];
@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AdminModuleRoutingModule { }
