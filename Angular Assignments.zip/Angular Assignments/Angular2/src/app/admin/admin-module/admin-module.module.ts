import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AdminModuleRoutingModule } from './admin-module-routing.module';
import { MenuComponent } from 'src/app/menu/menu.component';
import { RestaurantComponent } from 'src/app/restaurant/restaurant.component';
import { UserComponent } from 'src/app/user/user.component';
import { ButtonModule } from 'primeng/button';
import { BrowserModule } from '@angular/platform-browser';


@NgModule({
  declarations: [
     MenuComponent,
    RestaurantComponent,
    UserComponent,
  ],
  imports: [
    CommonModule,
    AdminModuleRoutingModule,
    ButtonModule,
    BrowserModule
  ]

})
export class AdminModuleModule { }
