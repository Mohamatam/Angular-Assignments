import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-advertisement-form-component',
  templateUrl: './advertisement-form-component.component.html',
  styleUrls: ['./advertisement-form-component.component.css']
})
export class AdvertisementFormComponentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
